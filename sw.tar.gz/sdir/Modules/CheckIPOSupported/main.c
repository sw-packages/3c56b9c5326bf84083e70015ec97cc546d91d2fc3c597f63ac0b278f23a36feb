int foo();

int main(void)
{
  return foo();
}
